Diese Version enthält die Fähigkeit, externe KIs wie Gemini oder Claude zu nutzen.
Build: EXE + Android