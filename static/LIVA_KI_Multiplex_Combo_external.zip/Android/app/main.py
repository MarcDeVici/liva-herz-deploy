# Kivy-Einstiegspunkt
print('L.I.V.A. Android mit KI-Multiplex')